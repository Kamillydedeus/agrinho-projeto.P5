function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let campo = [];

let cidade = [];

let conexoes = [];

let maxArvores = 50;

let maxPredios = 20;

function setup() {

  createCanvas(800, 400);

  

  // Criar elementos do campo (árvores)

  for (let i = 0; i < maxArvores; i++) {

    campo.push({

      x: random(width/4),

      y: random(height/2, height),

      tamanho: random(20, 50),

      cor: color(random(50, 150), random(100, 200), random(50, 150))

    });

  }

  

  // Criar elementos da cidade (prédios)

  for (let i = 0; i < maxPredios; i++) {

    let alt = random(50, 200);

    cidade.push({

      x: random(width/2, width),

      y: height - alt,

      largura: random(30, 80),

      altura: alt,

      cor: color(random(100, 200), random(100, 200), random(100, 200))

    });

  }

  

  // Criar conexões (caminhos entre campo e cidade)

  for (let i = 0; i < 10; i++) {

    conexoes.push({

      x1: random(width/4),

      y1: random(height/2, height),

      x2: random(width/2, width),

      y2: random(height/2, height),

      espessura: random(1, 3)

    });

  }

}

function draw() {

  background(220);

  

  // Desenhar céu

  drawGradient(0, 0, width, height/2, color(135, 206, 235), color(255));

  

  // Desenhar conexões (estradas/caminhos)

  for (let conexao of conexoes) {

    stroke(100, 80);

    strokeWeight(conexao.espessura);

    line(conexao.x1, conexao.y1, conexao.x2, conexao.y2);

  }

  

  // Desenhar campo (gramado)

  noStroke();

  fill(100, 180, 100);

  rect(0, height/2, width/2, height/2);

  

  // Desenhar árvores

  for (let arvore of campo) {

    fill(arvore.cor);

    ellipse(arvore.x, arvore.y, arvore.tamanho, arvore.tamanho);

    fill(139, 69, 19);

    rect(arvore.x - 5, arvore.y + arvore.tamanho/2, 10, 20);

  }

  

  // Desenhar cidade (calçada)

  fill(100);

  rect(width/2, height - 20, width/2, 20);

  

  // Desenhar prédios

  for (let predio of cidade) {

    fill(predio.cor);

    rect(predio.x, predio.y, predio.largura, predio.altura);

    

    // Janelas

    fill(255, 255, 150);

    let janelasX = floor(predio.largura / 15);

    let janelasY = floor(predio.altura / 20);

    

    for (let j = 0; j < janelasX; j++) {

      for (let k = 0; k < janelasY; k++) {

        if (random() > 0.3) { // Algumas janelas apagadas

          rect(

            predio.x + 5 + j * 15,

            predio.y + 5 + k * 20,

            8, 10

          );

        }

      }

    }

  }

  

  // Desenhar título

  fill(0);

  textSize(24);

  textAlign(CENTER);

  text("Conexão entre o Campo e a Cidade", width/2, 30);

}

function drawGradient(x, y, w, h, c1, c2) {

  noFill();

  for (let i = y; i <= y + h; i++) {

    let inter = map(i, y, y + h, 0, 1);

    let c = lerpColor(c1, c2, inter);

    stroke(c);

    line(x, i, x + w, i);

  }

}

function mousePressed() {

  // Adicionar uma nova conexão quando clicar

  conexoes.push({

    x1: random(width/4),

    y1: random(height/2, height),

    x2: random(width/2, width),

    y2: random(height/2, height),

    espessura: random(1, 3)

  });

  

  // Limitar o número de conexões

  if (conexoes.length > 15) {

    conexoes.shift();

  }

}